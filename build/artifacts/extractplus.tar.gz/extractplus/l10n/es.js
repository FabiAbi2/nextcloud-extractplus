OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "El cifrado aún no está soportado",
    "File not found" : "Archivo no encontrado",
    "Zip extension is not available" : "La extensión Zip no está disponible",
    "Cannot open Zip file" : "No se puede abrir el archivo Zip",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Oops, algo ha ido mal. Comprueba que tienes la extensión rar o que unrar está instalado",
    "Oops something went wrong." : "Oops, algo salió mal",
    "Extract" : "Extraer",
    "Extract archive from the web interface" : "Extraer el archivo desde la interfaz web",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Extraer archivadores.\n\n*  **Formatos soportados :** \n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requisitos:** \n    * Extensión  PHP rar  (pecl -v install rar)\n\n    * **O** \n    * unrar (sudo apt-get install unrar)\n\n    * **Y**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Nota :** Los archivos cifrados todavía no están soportados",
    "Extract here" : "Extraer aquí"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
