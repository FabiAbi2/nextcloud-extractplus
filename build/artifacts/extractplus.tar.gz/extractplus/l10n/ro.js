OC.L10N.register(
    "extractplus",
    {
    "File not found" : "Fișierul nu a fost găsit"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
