OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "Encryption is not supported yet",
    "File not found" : "File not found",
    "Zip extension is not available" : "Zip extension is not available",
    "Cannot open Zip file" : "Cannot open Zip file",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Oops something went wrong. Check that you have rar extension or unrar installed",
    "Oops something went wrong." : "Oops something went wrong.",
    "Extract" : "Extract",
    "Extract archive from the web interface" : "Extract archive from the web interface",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet",
    "Extract here" : "Extract here"
},
"nplurals=2; plural=(n != 1);");
