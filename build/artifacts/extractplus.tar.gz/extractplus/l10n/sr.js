OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "Шифрирање још увек није подржано",
    "File not found" : "Фајл није нађен",
    "Zip extension is not available" : "Zip екстензија није доступна",
    "Cannot open Zip file" : "Не може да се отвори Zip фајл",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Упсс, нешто је пошло наопако. Проверите да имате rar екстензију или да је инсталиран програм unrar",
    "Oops something went wrong." : "Упппс, нешто је пошло наопако.",
    "Extract" : "Отпакуј",
    "Extract archive from the web interface" : "Отпакујте архиве преко веб интерфејса",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Отпакујте архиве.\n\n*  **Подржано :** \n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Захтеви :** \n    * Rar PHP ектензија (pecl -v install rar)\n    \n    * **ИЛИ** \n    * unrar (sudo apt-get install unrar)\n\n    * **И**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Напомена:** шифровани фајлови још нису подржани",
    "Extract here" : "Отпакуј овде"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
