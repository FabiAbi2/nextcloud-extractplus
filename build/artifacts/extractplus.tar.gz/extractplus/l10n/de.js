OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "Verschlüsselung wird bislang nicht unterstützt",
    "File not found" : "Datei nicht gefunden",
    "Zip extension is not available" : "Zip-Erweiterung nicht verfügbar",
    "Cannot open Zip file" : "Zip-Datei kann nicht geöffnet werden",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Ups! Irgendwas lief schief. Überprüfe, ob du die Erweiterung rar oder unrar installiert hast",
    "Oops something went wrong." : "Etwas ist schiefgelaufen.",
    "Extract" : "Entpacken",
    "Extract archive from the web interface" : "Gepackte Datei aus dem Webinterface entpacken",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Archive extrahieren.\n\n*  **Unterstützt:**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n    * Zip\n\n*  **Anforderungen :**\n    * Rar PHP-Erweiterung (pecl -v install rar)\n\n    * **ODER**\n    * unrar (sudo apt-get install unrar)\n\n    * **UND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Hinweis:** Verschlüsselte Dateien werden noch nicht unterstützt",
    "Extract here" : "Hier entpacken"
},
"nplurals=2; plural=(n != 1);");
