OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "Henüz şifreleme desteklenmiyor",
    "File not found" : "Dosya bulunamadı",
    "Zip extension is not available" : "Zip eklentisi kullanılamıyor",
    "Cannot open Zip file" : "ZIP dosyası açılamadı",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Bir sorun çıktı. rar ya da unrar eklentilerinin kurulmuş olduğundan emin olun",
    "Oops something went wrong." : "Ne yazık ki bir sorun çıktı.",
    "Extract" : "Ayıkla",
    "Extract archive from the web interface" : "Arşivi site arayüzünden ayıkla",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Arşivleri ayıklar.\n\n* **Desteklenen uzantılar:**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n* **Gereksinimler: **\n    * Rar PHP eklentisi (pecl -v install rar)\n\n    * **YA DA**\n    * unrar (sudo apt-get install unrar)\n\n    * **VE** \n    *p7zip (sudo apt-get install p7zip p7zip-full)\n\n* **Not:** Şifrelenmiş dosyalar henüz desteklenmiyor.",
    "Extract here" : "Buraya ayıkla"
},
"nplurals=2; plural=(n > 1);");
