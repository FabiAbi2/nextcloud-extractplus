OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "Šifrování zatím není podporováno",
    "File not found" : "Soubor nenalezen",
    "Zip extension is not available" : "Rozšíření pro zip není k dispozici",
    "Cannot open Zip file" : "Soubor ZIP se nedaří otevřít",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Jejda! Něco se pokazilo. Zkontrolujte, zda máte nainstalovaný rar nebo unrar",
    "Oops something went wrong." : "Jejda, něco se pokazilo.",
    "Extract" : "Rozbalit",
    "Extract archive from the web interface" : "Rozbalit archiv z webového rozhraní",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Rozbalit archivy.\n\n*  **Podporováno:**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Vyžaduje:**\n    * PHP rozšíření pro formát rar (pecl -v install rar)\n\n    * **NEBO**\n    * unrar (sudo apt-get install unrar)\n\n    * **A**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Pozn.:** Šifrované soubory zatím nejsou podporovány",
    "Extract here" : "Rozbalit sem"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
