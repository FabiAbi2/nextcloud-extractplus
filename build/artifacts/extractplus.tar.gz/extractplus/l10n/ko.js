OC.L10N.register(
    "extractplus",
    {
    "Encryption is not supported yet" : "암호화는 아직 지원하지 않습니다.",
    "File not found" : "파일을 찾을 수 없음",
    "Zip extension is not available" : "Zip 확장 기능은 사용할 수 없습니다.",
    "Cannot open Zip file" : "Zip 파일을 열 수 없음",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "앗, 무엇인가 잘못되었습니다. rar 확장기능 혹은 unrar을 설치했는지 확인하십시오",
    "Extract" : "압축 풀기",
    "Extract archive from the web interface" : "웹 인터페이스에서 압축 풀기",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "아카이브 추출.\n\n*  **지원되는 형식 :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **요구사항 :**\n    * Rar PHP 확장  (pecl -v install rar)\n\n    * **또는**\n    * unrar (sudo apt-get install unrar)\n\n    * **그리고**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **유의 :** 암호화된 파일은 아직 지원되지 않습니다",
    "Extract here" : "여기에 압축 풀기"
},
"nplurals=1; plural=0;");
