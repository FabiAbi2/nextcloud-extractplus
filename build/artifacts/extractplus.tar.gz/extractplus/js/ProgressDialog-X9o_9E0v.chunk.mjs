import{t as r}from"./extractplus-main.mjs";const s="extractplus-progress-dialog-style",a=`
.extractplus-progress-dialog {
	border: none;
	border-radius: var(--border-radius-large, 12px);
	padding: 0;
	max-width: min(90vw, 480px);
	width: 480px;
	background-color: var(--color-main-background, #fff);
	color: var(--color-main-text, #222);
	box-shadow: 0 4px 24px rgba(0, 0, 0, 0.25);
}

.extractplus-progress-dialog::backdrop {
	background-color: rgba(0, 0, 0, 0.4);
}

.extractplus-progress-dialog__content {
	padding: 20px;
	display: flex;
	flex-direction: column;
	gap: 12px;
}

.extractplus-progress-dialog__title {
	margin: 0;
	font-size: 1.15em;
	font-weight: bold;
}

.extractplus-progress-dialog__archive {
	margin: 0;
	color: var(--color-text-maxcontrast, #6b6b6b);
	overflow-wrap: anywhere;
}

.extractplus-progress-dialog__track {
	height: 6px;
	border-radius: 3px;
	background-color: var(--color-background-dark, #ededed);
	overflow: hidden;
}

.extractplus-progress-dialog__bar {
	height: 100%;
	width: 0;
	border-radius: 3px;
	background-color: var(--color-primary-element, #0082c9);
	transition: width 0.3s ease-out;
}

/* Phases without a measurable percentage slide instead of filling up. */
.extractplus-progress-dialog__bar--indeterminate {
	width: 35% !important;
	transition: none;
	animation: extractplus-progress-slide 1.4s ease-in-out infinite;
}

@keyframes extractplus-progress-slide {
	0% { margin-inline-start: -35%; }
	100% { margin-inline-start: 100%; }
}

@media (prefers-reduced-motion: reduce) {
	.extractplus-progress-dialog__bar {
		transition: none;
	}

	.extractplus-progress-dialog__bar--indeterminate {
		animation-duration: 3s;
	}
}

.extractplus-progress-dialog__status {
	display: flex;
	justify-content: space-between;
	gap: 12px;
	font-size: 0.9em;
	color: var(--color-text-maxcontrast, #6b6b6b);
}

.extractplus-progress-dialog__file {
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
	direction: rtl;
	text-align: start;
}

.extractplus-progress-dialog__percent {
	flex: 0 0 auto;
	font-variant-numeric: tabular-nums;
}

.extractplus-progress-dialog__error {
	margin: 0;
	color: var(--color-error, #c74e4e);
}

.extractplus-progress-dialog__buttons {
	display: flex;
	justify-content: flex-end;
	gap: 8px;
}

.extractplus-progress-dialog__button {
	min-height: 34px;
	padding: 0 16px;
	border: none;
	border-radius: var(--border-radius-element, var(--border-radius-pill, 17px));
	background-color: var(--color-background-dark, #ededed);
	color: var(--color-main-text, #222);
	cursor: pointer;
	font-size: inherit;
}

.extractplus-progress-dialog__button:hover,
.extractplus-progress-dialog__button:focus-visible {
	background-color: var(--color-background-hover, #e5e5e5);
}
`;class i{dialog;titleEl;archiveEl;barEl;trackEl;fileEl;percentEl;errorEl;buttonsEl;closeButton;constructor(){i.injectStyles(),this.dialog=document.createElement("dialog"),this.dialog.className="extractplus-progress-dialog",this.dialog.setAttribute("aria-labelledby","extractplus-progress-dialog-title");const t=document.createElement("div");t.className="extractplus-progress-dialog__content",this.titleEl=document.createElement("h2"),this.titleEl.className="extractplus-progress-dialog__title",this.titleEl.id="extractplus-progress-dialog-title",this.archiveEl=document.createElement("p"),this.archiveEl.className="extractplus-progress-dialog__archive",this.trackEl=document.createElement("div"),this.trackEl.className="extractplus-progress-dialog__track",this.trackEl.setAttribute("role","progressbar"),this.trackEl.setAttribute("aria-valuemin","0"),this.trackEl.setAttribute("aria-valuemax","100"),this.barEl=document.createElement("div"),this.barEl.className="extractplus-progress-dialog__bar",this.trackEl.appendChild(this.barEl);const e=document.createElement("div");e.className="extractplus-progress-dialog__status",e.setAttribute("aria-live","polite"),this.fileEl=document.createElement("span"),this.fileEl.className="extractplus-progress-dialog__file",this.percentEl=document.createElement("span"),this.percentEl.className="extractplus-progress-dialog__percent",e.append(this.fileEl,this.percentEl),this.errorEl=document.createElement("p"),this.errorEl.className="extractplus-progress-dialog__error",this.errorEl.hidden=!0,this.buttonsEl=document.createElement("div"),this.buttonsEl.className="extractplus-progress-dialog__buttons",this.closeButton=document.createElement("button"),this.closeButton.className="extractplus-progress-dialog__button",this.closeButton.type="button",this.closeButton.addEventListener("click",()=>this.close()),this.buttonsEl.appendChild(this.closeButton),t.append(this.titleEl,this.archiveEl,this.trackEl,e,this.errorEl,this.buttonsEl),this.dialog.appendChild(t)}static injectStyles(){if(document.getElementById(s)!==null)return;const t=document.createElement("style");t.id=s,t.textContent=a,document.head.appendChild(t)}open(t){this.titleEl.textContent=r("extractplus","Extracting archive"),this.archiveEl.textContent=t,this.errorEl.hidden=!0,this.closeButton.textContent=r("extractplus","Hide"),this.setIndeterminate(!0),this.fileEl.textContent=r("extractplus","Preparing…"),this.percentEl.textContent="",document.body.appendChild(this.dialog),this.dialog.showModal()}update(t){if(t.phase==="registering"){this.setIndeterminate(!0),this.fileEl.textContent=r("extractplus","Adding files to Nextcloud…"),this.percentEl.textContent="";return}if(t.phase!=="extracting")return;const e=Math.max(0,Math.min(100,t.percent));this.setIndeterminate(!1),this.barEl.style.width=`${e}%`,this.trackEl.setAttribute("aria-valuenow",String(Math.round(e))),this.percentEl.textContent=`${Math.round(e)} %`,t.currentFile!==""?(this.fileEl.textContent=t.currentFile,this.fileEl.title=t.currentFile):t.filesTotal>0&&(this.fileEl.textContent=r("extractplus","{done} of {total} files",{done:String(t.filesDone),total:String(t.filesTotal)}))}finish(){this.setIndeterminate(!1),this.barEl.style.width="100%",this.trackEl.setAttribute("aria-valuenow","100"),this.percentEl.textContent="100 %",this.fileEl.textContent=r("extractplus","Done"),setTimeout(()=>this.close(),500)}fail(t){this.setIndeterminate(!1),this.barEl.style.width="0",this.titleEl.textContent=r("extractplus","Extraction failed"),this.fileEl.textContent="",this.percentEl.textContent="",this.errorEl.textContent=t,this.errorEl.hidden=!1,this.closeButton.textContent=r("extractplus","Close"),this.closeButton.focus()}close(){this.dialog.open&&this.dialog.close(),this.dialog.remove()}setIndeterminate(t){this.barEl.classList.toggle("extractplus-progress-dialog__bar--indeterminate",t),t&&(this.trackEl.removeAttribute("aria-valuenow"),this.barEl.style.width="")}}export{i as ProgressDialog};
//# sourceMappingURL=ProgressDialog-X9o_9E0v.chunk.mjs.map
